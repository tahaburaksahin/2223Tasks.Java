package _2324Z.wis.eng.gr39.ppj_05;

import java.util.Scanner;

public class Task4 {
    public static void main(String[] args) {
        int a, b, c;

        Scanner scanner = new Scanner(System.in);
        a = scanner.nextInt(); // 2
        b = scanner.nextInt(); // 2
        c = scanner.nextInt(); // 4

        if ((a == b && a != c) ||
                (a == c && a != b) ||
                (c == b && c != a)) {
            System.out.println("OK");
        } else {
            System.out.println("NOT OK");
        }


        /**/
    }
}
