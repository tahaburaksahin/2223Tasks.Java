package _2324Z.wis.eng.gr39.ppj_05;

public class Example {
    public static void main(String[] args) {
        char c1, c2, c3, c4;
        c1 = 'a'; // ascci : 97
        c2 = 'd'; // ascii : 100
        c3 = 'a';

        System.out.println(c1); // a
        System.out.println(c2); // d
        System.out.println(c1 + c2); // ad, number ans: 197

        System.out.println(c3++); // a, c3 = (char)('a' + 1) -> c3 = 'b'
        System.out.println(c3); // b
        System.out.println(++c3); // c3 = (char)('b' + 1) -> c3 = 'c'
        System.out.println(c3); // c

    }
}
