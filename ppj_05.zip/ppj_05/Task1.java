package _2324Z.wis.eng.gr39.ppj_05;

import javax.swing.*;
import java.util.Scanner;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Task1 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double weight, height;

        System.out.print("Input your weight :");
        weight = sc.nextDouble();
        System.out.print("Input your height :");
        height = sc.nextDouble();
        System.out.println();

        double bmi = (weight) / (height * height);

        System.out.println("Your BMI is " + bmi);
        sc.nextLine();
        JOptionPane.showMessageDialog(null, "Your BMI is " + bmi, "BMI", INFORMATION_MESSAGE);
    }
}
