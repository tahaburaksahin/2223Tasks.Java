package _2324Z.wis.eng.gr39.ppj_05;

import javax.swing.*;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Task1GUI {
    public static void main(String[] args) {
        double weight, height;
        weight = Double.parseDouble(
                JOptionPane.showInputDialog("Input your weight :", 0)
        );
        height = Double.parseDouble(
                JOptionPane.showInputDialog("Input your weight :", 0)
        );

        double bmi = (weight) / (height * height);
        System.out.println("Your BMI is " + bmi);

        JOptionPane.showMessageDialog(
                null, "Your BMI is " + bmi, "BMI", INFORMATION_MESSAGE
        );
    }
}

