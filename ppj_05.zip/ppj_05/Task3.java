package _2324Z.wis.eng.gr39.ppj_05;

import javax.swing.*;
import java.util.Scanner;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Task3 {
    public static void main(String[] args) {
        double a, b, c, delta;

        Scanner scanner = new Scanner(System.in);
        a = scanner.nextDouble(); // 2
        b = scanner.nextDouble(); // 3
        c = scanner.nextDouble(); // -4

        delta = b * b - 4 * a * c;
        String info = "";
        if (delta < 0) {
            info = "There is no answer.";
        } else {
            if (delta == 0) {
                double result0 = -b / (2 * a);
                info = "There is one answer, x0 = " + result0;
            } else {
                double result1 = (-b + Math.sqrt(delta)) / (2 * a);
                double result2 = (-b - Math.sqrt(delta)) / (2 * a);
                info = "There is two answers, x1 = " + result1 + " and x2 = " + result2;
            }
        }
        JOptionPane.showMessageDialog(null, info, "Calculator", INFORMATION_MESSAGE);
    }
}
