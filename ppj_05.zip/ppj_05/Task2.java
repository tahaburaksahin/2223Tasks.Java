package _2324Z.wis.eng.gr39.ppj_05;

import javax.swing.*;

import static javax.swing.JOptionPane.INFORMATION_MESSAGE;

public class Task2 {
    public static void main(String[] args) {
        double d1, d2, result = 0;
        String op;

        d1 = Double.parseDouble(JOptionPane.showInputDialog("Input first number: "));
//        op = (String) JOptionPane.showInputDialog(null,
//                "Input second number: ", "", JOptionPane.INFORMATION_MESSAGE,
//                null, new Object[]{"+", "-", "*", "/"}, "+");
        op = JOptionPane.showInputDialog("Input [+, -, *, /, ^]: ");
        d2 = Double.parseDouble(JOptionPane.showInputDialog("Input second number: "));

        if (op.equals("+")) {
            result = d1 + d2;
        }
        if (op.equals("-")) {
            result = d1 - d2;
        }
        if (op.equals("*")) {
            result = d1 * d2;
        }
        if (op.equals("/")) {
            result = d1 / d2;
        }
        if (op.equals("^")) {
            result = Math.pow(d1, d2);
        }

        JOptionPane.showMessageDialog(
                null, "Your result is " + result, "Calculator", INFORMATION_MESSAGE
        );
    }
}
