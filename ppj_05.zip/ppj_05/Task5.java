package _2324Z.wis.eng.gr39.ppj_05;

import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        int a, b, c;

        Scanner scanner = new Scanner(System.in);
        a = scanner.nextInt(); // 5
        b = scanner.nextInt(); // 3
        c = scanner.nextInt(); // 4

        if (a + b > c && a + c > b && c + b > a) {
            System.out.println("OK");
        } else {
            System.out.println("NOT OK");
        }


        /**/
    }
}
